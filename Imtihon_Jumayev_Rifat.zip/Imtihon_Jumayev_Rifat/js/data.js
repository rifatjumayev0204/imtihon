const things = [
  {
    id: 1,
    title: "Hyacinth macaw",
    img: "https://media.istockphoto.com/photos/parrot-hyacinth-macaw-picture-id1359443019?b=1&k=20&m=1359443019&s=170667a&w=0&h=dteRZ9bM7sEvBbFE9it1r9O7IxlILXb1UnSoLNEVMAg=",
    price: 5000,
    birthDate: "2022-01-12",
    sizes: {
      width: 184,
      height: 50
    },
    isFavorite: true,
    features: "Beautiful,Tame,Can speak"
  },
  {
    id: 2,
    title: "Qizil Ara",
    img: "https://media.istockphoto.com/photos/amazon-rainforest-parrot-macaw-picture-id1197182594?b=1&k=20&m=1197182594&s=170667a&w=0&h=bBQfSDgofCr_w2DBf79cwQe-JA45i02vCv7Ttx5qcmU=",
    price: 1200,
    birthDate: "2022-02-09",
    sizes: {
      width: 235,
      height: 100
    },
    isFavorite: true,
    features: ""
  },
  {
    id: 3,
    title: "Sariq tojli oq Kakatu",
    img: "https://media.istockphoto.com/photos/sulphur-crested-cockatoo-picture-id1322969996?k=20&m=1322969996&s=612x612&w=0&h=jceOFxtD6QmLKqKxUxdGFTVc7bATCCVcwpwUSCca0aE=",
    price: 1500,
    birthDate: "2022-02-20",
    sizes: {
      width: 138,
      height: 84
    },
    isFavorite: false,
    features: "bv"
  }
]

const favorites = [
  
];