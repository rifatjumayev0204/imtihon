const elThingTemplate = document.querySelector("#things-template");  
const elThingsWrapper = document.querySelector("#parrots-wrapper");

let parrotDB = [...things];

//get document 
function getDocument(qurselector){
  return document.querySelector(qurselector)
}
//parrot filter
let filName, filPriceFrom, filPriceTo, filWidthFrom, filWidthTo, filHeightFrom, filHeightTo, filSort;
document.querySelector('.filterBtn').addEventListener('click', (e)=>{
  e.preventDefault()
  filName = getDocument('#search').value;
  filPriceFrom = getDocument('#from_price').value;
  filPriceTo = getDocument('#to_price').value;
  filWidthFrom = getDocument('#from_width').value;
  filWidthTo = getDocument('#to_width').value;
  filHeightFrom = getDocument('#from_height').value;
  filHeightTo = getDocument('#to_height').value;
  filSort = getDocument('#sortby').value;
  
    const sortData = parrotDB
    .filter(item => {
      if(filName){
        if (item.title.indexOf(filName) > -1) {
          return item
        }
      }else{
        return item
      }
      
    })
    .filter(item => {
      if(filPriceFrom || filPriceTo){
        if(filPriceFrom && filPriceTo){
            if (item.price >= +filPriceFrom ) {
              if (item.price <= +filPriceTo ) {
                return item
              }
            }
          }else{
            if(filPriceFrom){
              if (item.price >= +filPriceFrom ) {
                return item
              }
            }
            if (filPriceTo){
              if (item.price <= +filPriceTo ) {
                return item
              }
            }
          }
        
      }else{
        return item
      }
    })
    .filter(item => {
      if(filWidthFrom || filWidthTo){
        if(filWidthFrom && filWidthTo){
            if (item.sizes.width >= +filWidthFrom ) {
              if (item.sizes.width <= +filWidthTo ) {
                return item
              }
            }
          }else{
            if(filWidthFrom){
              if (item.sizes.width >= +filWidthFrom ) {
                return item
              }
            }
            if (filWidthTo){
              if (item.sizes.width <= +filWidthTo ) {
                return item
              }
            }
          }
        
      }else{
        return item
      }
    })
    .filter(item => {
      if(filHeightFrom || filHeightTo){
        if(filHeightFrom && filHeightTo){
            if (item.sizes.height >= +filHeightFrom ) {
              if (item.sizes.height <= +filHeightTo ) {
                return item
              }
            }
          }else{
            if(filHeightFrom){
              if (item.sizes.height >= +filHeightFrom ) {
                return item
              }
            }
            if (filHeightTo){
              if (item.sizes.height <= +filHeightTo ) {
                return item
              }
            }
          }
        
      }else{
        return item
      }
    })
    .sort((a, b) => {
      switch (filSort) {
        case "1":
          if (a.title > b.title) {
            return 1
          } else if (a.title === b.title) {
            return 0
          }
          return -1;
        case "2":
          return b.price - a.price;
        case "3":
          return a.price - b.price;
        case "4":
          return new Date(a.birthDate) - new Date(b.birthDate)
        
        case "5":
          return new Date(b.birthDate) - new Date(a.birthDate)
        
      }

      return 0;
    });
   
    renderThins(sortData)
  
})
function renderThins(data){
  elThingsWrapper.innerHTML = ``;
  data.forEach(element => {
    let clas = ''
    if(element.isFavorite){
      clas = 'fa fa-star-o';
    }else{
      clas = 'fa-solid fa-star';
    }
    elThingsWrapper.innerHTML += `<li class="col-6">
    <div class="card">
      <img id="img-id" src="${element.img}" alt="" class="card-img-top">
      <div class="card-body">
        <h3 id="title-id" class="card-title">${element.title}</h3>
        <p class="badge bg-success">${element.sizes.width}sm x ${element.sizes.height}x</p>
        <p class="card-text fw-bold">${element.birthDate}</p>

        <p class="date-id-id card-text">${element.features}</p>
        <p class="date-id-id fw-bold">${element.price}$</p>

        <ul class="d-flex flex-wrap list-unstyled">
          <li id="power1" class="badge power1 bg-primary me-1 mb-1"></li>
          <li class="badge power2 bg-primary me-1 mb-1"></li>
          <li class="badge power3 bg-primary me-1 mb-1"></li>
        </ul>

        <div class="position-absolute top-0 end-0 d-flex">
          <!-- Agar isFavorite false bo'ladigan bo'lsa i'ning classi "fa-solid fa-star" bo'lishi kerak. Agar unday bo'lmasa "fa fa-star-o" -->
          <button id="${element.id}" class="likeForm btn rounded-0 btn-success"><i class="${clas}" style="color: yellow; pointer-events: none;" aria-hidden="true"></i></button>
          <button id="${element.id}" class="editForm btn rounded-0 btn-secondary" data-bs-toggle="modal" data-bs-target="#add-parrot-modal"><i class="fa-solid fa-pen" style="pointer-events: none;"></i></button>
          <button id="${element.id}" class="deleteForm btn rounded-0 btn-danger"><i class="fa-solid fa-trash" style="pointer-events: none;"></i></button>
        </div>
      </div>
    </div>
  </li>`
  });
}
renderThins(parrotDB);
  


//   navbatdegi ish add boshlandi (tepa toza)
const elAddThingForm = document.querySelector("#addForm");
const editBtn = document.querySelector('.editForm');
const addParrot = document.querySelector('.addParrot');
addParrot.addEventListener('click', () => {
    elAddThingForm.classList.add('addBtn')
    elAddThingForm.classList.remove('editBtn')
    elAddThingForm.textContent = 'Add'
    document.querySelector(".title-id").value = '';
    document.querySelector(".img-value").value = '';
    document.querySelector(".price-value").value = '';
    document.querySelector(".date-value").value = '';
    document.querySelector("#parrot_width").value = '';
    document.querySelector("#parrot_height").value = '';
    document.querySelector(".fea-value").value = '';
})
elThingsWrapper.addEventListener('click', (e) =>{
  //edit parrot
  if(e.target.classList.contains('editForm')){
    elAddThingForm.classList.remove('addBtn')
    elAddThingForm.classList.add('editBtn')
    elAddThingForm.textContent = 'Edit'

    const target = e.target
    document.querySelector('.editBtn').id = 'editForm'
  const obj = parrotDB.filter((item) => {
      if(target.id == item.id){
        return item
      }
  })[0];
      
      document.querySelector(".title-id").value = obj.title;
      document.querySelector(".img-value").value = obj.img;
      document.querySelector(".price-value").value = obj.price;
      document.querySelector(".date-value").value = obj.birthDate;
      document.querySelector("#parrot_width").value = obj.sizes.width;
      document.querySelector("#parrot_height").value = obj.sizes.height;
      document.querySelector(".fea-value").value = obj.features;
      elAddThingForm.setAttribute('data-id', obj.id);
  }
    //  delete parrot
  if(e.target.classList.contains('deleteForm')){
    const id = e.target.id;
    parrotDB = parrotDB.filter(item => item.id != id)
    renderThins(parrotDB);
  }
  // edit favorite parrot

  if (e.target.classList.contains('likeForm')) {
    const id = e.target.id;
    parrotDB = parrotDB.map(item => {
      if(item.id == id){
        item.isFavorite = !item.isFavorite;
      }
      return item
    });
    renderThins(parrotDB);
  }
  
  
})
  // add new parrot and edit parrot
document.querySelector("#addForm").addEventListener('click', (e) => {
  e.preventDefault();
  // add parrot
  if(e.target.classList.contains('addBtn')){
    
    const elTitleV = document.querySelector(".title-id").value;
    const elImgV = document.querySelector(".img-value").value;
    const elPriceV = document.querySelector(".price-value").value;
    const elDateV = document.querySelector(".date-value").value;
    const elWidthV = document.querySelector("#parrot_width").value;
    const elHeightV = document.querySelector("#parrot_height").value;
    const elFeaV = document.querySelector(".fea-value").value;
    function newData(){
      if (elTitleV && elImgV && elPriceV && elDateV && elWidthV && elHeightV) {
        const addingThing = {
          id: Math.floor(Math.random() * 1000),
          title: elTitleV,
          img: elImgV,
          price: elPriceV,
          birthDate: elDateV,
          sizes: {
            width: elWidthV,
            height: elHeightV,
          },
          isFavorite: true,
          features:  elFeaV, 
        }
        parrotDB.unshift(addingThing);
        renderThins(parrotDB);
      }
      
    }
    newData();
  }

  // edit parrot
  if(e.target.classList.contains('editBtn')){ 

    const elTitleV = document.querySelector(".title-id").value;
    const elImgV = document.querySelector(".img-value").value;
    const elPriceV = document.querySelector(".price-value").value;
    const elDateV = document.querySelector(".date-value").value;
    const elWidthV = document.querySelector("#parrot_width").value;
    const elHeightV = document.querySelector("#parrot_height").value;
    const elFeaV = document.querySelector(".fea-value").value;
    const id = elAddThingForm.getAttribute('data-id')
    parrotDB = parrotDB.map(item => {
        if(item.id == id){
          item = {
                id: id,
                title: elTitleV,
                img: elImgV,
                price: elPriceV,
                birthDate: elDateV,
                sizes: {
                  width: elWidthV,
                  height: elHeightV,
                },
                features:  elFeaV,
          }
        }
        return item;
    })
    
  }

  //delete parrot
 
  renderThins(parrotDB);
  
});






  
  

