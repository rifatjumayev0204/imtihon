const elParrotTemplate = document.querySelector("#parrots-tempate");
const elParrotWrapper = document.querySelector(".parrots-wrapper");
const elAddParrotModal = document.querySelector("#add-parrot-modal");
const elAddModal = new bootstrap.Modal(elAddParrotModal);




const createParrotlist = (product) => {
    const { id, title, img, price, birthDate, sizes, isFavorite, features } =
    product;

    const elParrotList = elParrotTemplate.cloneNode(true).content;

    const elParrotId = elParrotList.querySelector('.id');
    elParrotId.textContent = `${ id }`;

    const elParrotImg = elParrotList.querySelector("#card-img");
    elParrotImg.src = img;

    const elParrotTitle = elParrotList.querySelector("#card-title");
    elParrotTitle.textContent = title;

    const elParrotPrice = elParrotList.querySelector("#card-price");
    elParrotPrice.textContent = "$" + `${price}`;

    const elParrotSize = elParrotList.querySelector("#card-size");
    elParrotSize.textContent = `$ { sizes.width } sm x $ { sizes.height } sm`;

    const elTelDate = elParrotList.querySelector("#birth-data");
    const parrotsDate = new Date(birthDate);

    elTelDate.textContent = `${addZero(parrotsDate.getDate())}.${addZero(
    parrotsDate.getMonth() + 1
  )}.${parrotsDate.getFullYear()} ${addZero(parrotsDate.getHours())}:${addZero(
    parrotsDate.getMinutes()
  )}`;

    const elParrotFeatures = elParrotList.querySelector("#parrot-features");
    elParrotFeatures.textContent = features;


    const elIsFavorite = elParrotList.querySelector('.btn-success')
    elIsFavorite.value = isFavorite;


    const elAddBtn = elParrotList.querySelector(".btn-trash");
    elAddBtn.dataset.id = id;

    const elSuccessBtn = elParrotList.querySelector(".btn-success");
    elSuccessBtn.dataset.id = id;

    const elEditBtn = elParrotBox.querySelector(".btn-secondary");
    elEditBtn.dataset.id = id;


    return elParrotList;
};

const render = (e) => {
    elParrotWrapper.innerHTML = ""
    if (el) {
        e.forEach((parrots) => {
            const templateList = createTemplateList(parrots);
            elParrotWrapper.appendChild(templateList)

        })
    } else {
        parrots.forEach((parrots) => {
            const templateList = createTemplateList(parrots);
            elParrotWrapper.appendChild(templateList)
        })
    }
}
render();


const elAddForm = document.querySelector('.add-parrot-form');
elAddForm.addEventListener('submit', (el) => {
    el.preventDefault()
    const elTitle = elAddForm.parrot_title.value.trim();
    const elImg = elAddForm.parrot_img.value.trim();
    const elPrice = elAddForm.price.value.trim();
    const elDate = elAddForm.parrot_date.value.trim();
    const elWidth = elAddForm.parrot_width.value.trim();
    const elHeight = elAddForm.parrot_height.value.trim();
    const elFeatures = elAddForm.features.value.trim();


    if (elTitle && elImg && elPrice > 0 && elDate && elWidth > 0 && elHeight && elFeatures) {
        const addingParrots = {
            id: Math.floor(Math.random() * 1000),
            title: elTitle,
            img: elImg,
            price: elPrice,
            birthDate: elDate,
            sizes: {
                width: elWidth,
                height: elHeight
            },
            features: elFeatures
        }
        parrots.unshift(addingParrots)
        render();
        console.log(parrots);

    }

});


const elEditForm = document.querySelector(".edit-modal-form");
const elEditFormTitle = elEditForm.querySelector("#edit-parrot-title");
const elEditFormImg = elEditForm.querySelector("#edit-parrot-img");
const elEditFormPrice = elEditForm.querySelector("#edit-price");
const elEditFormBirthdate = elEditForm.querySelector("#edit-parrot-date");
const elEditFormWidth = elEditForm.querySelector("#edit-parrot_width");
const elEditFormHeight = elEditForm.querySelector("#edit-parrot_height");
const elEditFormFeatures = elEditForm.querySelector("#edit-features");
const elEditModal = document.querySelector("#edit-parrot-modal");
const editParrotModal = new bootstrap.Modal(elEditModal);

elParrotCardList.addEventListener("click", (evt) => {
    evt.preventDefault();
    if (evt.target.matches(".delete-btn")) {
        const clickedBtnId = +evt.target.dataset.id;
        const clickedBtnIndex = products.findIndex((parrot) => {
            return parrot.id === clickedBtnId;
        });
        products.splice(clickedBtnIndex, 1);
        renderFunction();
    } else if (evt.target.matches(".edit-btn")) {
        const clickedBtnId = +evt.target.dataset.id;

        const clickedItem = products.find((parrot) => {
            return parrot.id === clickedBtnId;
        });
        elEditFormTitle.value = clickedItem.title;
        elEditFormImg.value = clickedItem.img;
        elEditFormPrice.value = clickedItem.price;
        elEditFormBirthdate.value = clickedItem.birthDate;
        elEditFormWidth.value = clickedItem.sizes.width;
        elEditFormHeight.value = clickedItem.sizes.height;
        elEditFormFeatures.value = clickedItem.features;
        elEditForm.setAttribute("data-editing-id", clickedItem.id);
    } else

    if (evt.target.matches(".btn-fovorite")) {
        const clickedBtnId = +evt.target.dataset.id;

        const clickedItem = products.find((parrot) => {
            return parrot.id === clickedBtnId;
        });
    }
})

elEditForm.addEventListener("submit", (evt) => {
    evt.preventDefault();
    const editingId = +evt.target.dataset.editingId;
    const elParrotTitle = elEditFormTitle.value.trim();
    const elParrotImg = elEditFormImg.value.trim();
    const elParrotPrice = +elEditFormPrice.value.trim();
    const elParrotBirthDate = elEditFormBirthdate.value.trim();
    const elParrotWidth = +elEditFormWidth.value.trim();
    const elParrotHeigth = +elEditFormHeight.value.trim();
    const elParrotFeatures = elEditFormFeatures.value.trim();

    if (elParrotTitle && elParrotImg && elParrotBirthDate && elParrotWidth > 0 && elParrotHeigth > 0 && elParrotPrice > 0) {
        const newParrot = {
            id: editingId,
            title: elParrotTitle,
            img: elParrotImg,
            price: elParrotPrice,
            birthDate: elParrotBirthDate,
            sizes: {
                width: elParrotWidth,
                height: elParrotHeigth
            },
            isFavorite: false,
            features: elParrotFeatures
        }
        const editItemIndex = products.findIndex((parrot) => {
            return parrot.id === editingId;
        });
        products.splice(editingItemIndex, 1, newParrot);
        editParrotModal.hide();
        renderFunction();

    }
})

const elParrotFilter = document.querySelector("#parrot-filter");
elParrotFilter.addEventListener("submit", (evt) => {
    evt.preventDefault();
    const elementList = evt.target.elements
    const elParrotSearch = elementList.search.value;
    const elFromValue = +elementList.from.value;
    const elToValue = +elementList.to.value;
    const elParrotWidthValue = +elementList.from_width.value;
    const elWidthValue = +elementList.to_width.value;
    const elHeightValue = +elementList.from_height.value;
    const elToHeightValue = +elementList.to_height.value;
    const elSortValue = elementList.sortby.value;
    const elFiltredCards = products.filter((parrot) => {
            return parrot.title.toLowerCase().includes(elParrotSearch.toLowerCase());
        })
        .filter(parrot => {
            const parrotPrice = +parrot.price;
            return elFromValue ? parrotPrice >= elFromValue : true;
        })
        .filter(parrot => {
            const parrotHeight = +parrot.sizes.height;
            return elHeightValue ? parrotHeight >= elHeightValue : true;
        })
        .filter(parrot => {
            const parrotHeight = +parrot.sizes.height;
            return elHeightValue < elToHeightValue ? parrotHeight <= elToHeightValue : true;
        })

    .sort((a, b) => {
        if (elSortValue === "1") {
            if (a.title > b.title) {
                return 1;
            } else if (a.title === b.title) {
                return 0;
            }
            return -1;
        }
    });
    render(elFiltredCards);
})